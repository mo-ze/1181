/**
 * drawing interface
 */
public interface ASCIIDrawable {
    /**
     * abstract method to be implemented
     * @return
     */
    abstract String drawAsACII();

}
