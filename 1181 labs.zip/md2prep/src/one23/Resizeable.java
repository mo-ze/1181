package one23;

public interface Resizeable {

    public  void Scale(int sf);
}
